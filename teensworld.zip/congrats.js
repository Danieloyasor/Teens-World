alert("Yay! thank you for your Kind donations!!");

